package com.sbt.commons

import com.sbt.commons.dto.Job.Job

/**
  * Created by fsznajderman on 09/01/2016.
  */
object dto {

  case class User(nom: String, prenom: String, age: Int, ville: String, job: Job)

  /**
    * Job enumeration
    */
  object Job extends Enumeration {
    type Job = Value

    val stagiaire, rh, dev, comptable, pdg = Value
  }


}
