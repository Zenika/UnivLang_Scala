package com.sbt.service

import com.sbt.commons.dto.{Job, User}
import org.scalatest.FunSuite

/**
  * Created by fsznajderman on 09/01/2016.
  */
class UserServiceTest extends FunSuite {

  test("add user") {
     UserService.addUser(User("Paul", "Louis", 25, "Paris",  Job.comptable))

    UserService.loadUser("Paul").isDefined

  }

  test("load one user") {
    UserService.addUser(User("Paul", "Louis", 25, "Paris",  Job.comptable))
    UserService.addUser(User("Michel", "Patrice", 45, "Lille",  Job.stagiaire))
    UserService.addUser(User("Sebastien", "miro", 24, "Caen",  Job.stagiaire))

    UserService.loadUser("Paul").isDefined

  }

  test("findByName") {
    UserService.addUser(User("Paul", "Louis", 25, "Paris",  Job.comptable))
    UserService.addUser(User("Michel", "Patrice", 45, "Lille",  Job.stagiaire))
    UserService.addUser(User("Sebastien", "miro", 24, "Caen",  Job.stagiaire))

    UserService.findByName("Paul").size == 1

  }


}
