package com.sbt.service

import com.sbt.commons.dto.User
import com.sbt.repository.UserRepository


/**
  * Created by fsznajderman on 09/01/2016.
  */
object UserService {


  def addUser(u: User): Unit = UserRepository.createUser(u)


  def loadUser(nom: String): Option[User] = UserRepository.getUser(nom)


  def findByName(nom: String): Set[User] = UserRepository.selectFromRegex(u => u.nom == nom)

  //def findByAge(age: Int): Set[User] = UserRepository.selectFromRegex(u => u.age > age)


}
