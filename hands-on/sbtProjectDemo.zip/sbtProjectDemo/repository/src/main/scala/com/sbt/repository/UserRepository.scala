package com.sbt.repository

import com.sbt.commons.dto.User


/**
  * Created by fsznajderman on 09/01/2016.
  */
object UserRepository {

  var usersRepo = Set[User]();

  def createUser(u: User) = {
    usersRepo += u
  }


  /*def deleteUSer(u: User) = {
    usersRepo -= u
  } */


  def getUser(nom: String): Option[User] = {
    Option(usersRepo.filter(u => u.nom == nom).head)
  }

  def getAll(): Set[User] = usersRepo.seq

  def selectFromAge(filter: User => Boolean): Set[User] = {
    usersRepo.filter(filter).seq
  }

  def selectFromRegex(filter: User => Boolean): Set[User] = {
    usersRepo.filter(filter).seq
  }


}


