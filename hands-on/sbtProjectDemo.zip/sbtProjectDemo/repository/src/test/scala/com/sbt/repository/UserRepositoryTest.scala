package com.sbt.repository

import com.sbt.commons.dto.{Job, User}
import org.scalatest.FunSuite

/**
  * Created by fsznajderman on 09/01/2016.
  */
class UserRepositoryTest extends FunSuite {



  test("create user") {

    val u = User("Sznajderman", "Fabrice", 39, "Paris", Job.dev)
    UserRepository.createUser(u)

    UserRepository.getUser("Sznajderman").isDefined


  }

  test("select one user") {

    val u1 = User("Sznajderman", "Fabrice", 39, "Paris", Job.dev)
    val u2 = User("Vayssiere", "Geraldine", 38, "Paris", Job.rh)
    UserRepository.createUser(u1)
    UserRepository.createUser(u2)

    UserRepository.getUser("Vayssiere").isDefined

  }

  test("get all users") {

    val u1 = User("Sznajderman", "Fabrice", 39, "Paris", Job.dev)
    val u2 = User("Vayssiere", "Geraldine", 38, "Paris", Job.rh)
    val u3 = User("Dumas", "Olivier", 24, "Paris", Job.pdg)
    UserRepository.createUser(u1)
    UserRepository.createUser(u2)
    UserRepository.createUser(u3)

    UserRepository.getAll().size == 3

  }

  test("set of filtered user by age") {

    val u1 = User("Sznajderman", "Fabrice", 50, "Paris", Job.dev)
    val u2 = User("Vayssiere", "Geraldine", 38, "Paris", Job.rh)
    val u3 = User("Dumas", "Olivier", 24, "Paris", Job.pdg)
    UserRepository.createUser(u1)
    UserRepository.createUser(u2)
    UserRepository.createUser(u3)

    UserRepository.selectFromAge(user => user.age > 37).size == 2

  }

  test("set of filtered user by regex") {

    val u1 = User("Sznajderman", "Fabrice", 50, "Paris", Job.dev)
    val u2 = User("Vayssiere", "Geraldine", 38, "Paris", Job.rh)
    val u3 = User("Dumas", "Olivier", 24, "Paris", Job.pdg)
    UserRepository.createUser(u1)
    UserRepository.createUser(u2)
    UserRepository.createUser(u3)

    UserRepository.selectFromAge(user => user.nom contains("m")).size == 2

  }

}
